// src/App.tsx
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement } from './counterSlice';
import { RootState, AppDispatch } from './store';
import './App.css';

function App() {
  const dispatch: AppDispatch = useDispatch();
  const count = useSelector((state: RootState) => state.counter.value);

  return (
    <div className="App">
      <header className="App-header">
        <h1>Redux Toolkit + TypeScript + Vite Counter App</h1>
        <p>Count: {count}</p>
        <div>
          <button onClick={() => dispatch(increment())}>Increment</button>
          <button onClick={() => dispatch(decrement())}>Decrement</button>
        </div>
      </header>
    </div>
  );
}

export default App;
